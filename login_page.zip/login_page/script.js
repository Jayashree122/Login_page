document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var errorMessage = document.getElementById('error-message');

    // Example validation: check if the username and password match a hard-coded value
    if (username === 'user' && password === 'password') {
        errorMessage.textContent = '';
        alert('Login successful!');
        // You can add code here to redirect the user to another page or process the login further
    } else {
        errorMessage.textContent = 'Invalid username or password';
    }
});
